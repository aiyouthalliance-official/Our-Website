<?php

$notifications = [
    "",
    "AI Youth Alliance is hosting an exciting workshop on Google Duplex 10 December 2024! <a href='https://forms.gle/XhBYmK5JPx2qByan6' target='_blank'>Register here</a>!"
];

?>
