require('dotenv').config();

// Add your main application logic here
console.log("Environment variables loaded.");
